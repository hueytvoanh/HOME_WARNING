
#include <ArduinoJson.h>
#include <WebServer.h>
#include <WebSocketsServer.h>

#include "timecore.h"
#include "datastore.h"
#include "NTP_Client.h"
#include "led.h"

#include "webfunctions.h"
#include "websocket_if.h"

#include "String.h"
#define MASTER_RUNNING       0
#define MASTER_WARNING       1
#define MASTER_IDLE          2

#define NODE_RUNNING         0
#define NODE_WARNING         1
#define NODE_IDLE            2

#define SYSTEM_RUNNING       0
#define SYSTEM_WARNING       1
#define SYSTEM_IDLE          2
#define SYSTEM_SENDING       3
#define SYSTEM_SENDING_ERROR 4
#define SYSTEM_ESP_NOW_ERROR 5
#define SYSTEM_RUN_WARN      6 
#define SYSTEM_RUNN_IDLE     7
#define SYSTEM_IDLE_RUNN     8 
#define NO_CHANGE            9    


extern NTP_Client NTPC;
extern Timecore timec;
extern void sendData(String data);
extern WebServer * server;
extern TaskHandle_t MQTTTaskHandle;

extern int var;
extern volatile int masterState, systemState, systemChangeCode;
//extern volatile int timeToRun;

neoSettings_t neo_settings;

/**************************************************************************************************
*    Function      : response_settings
*    Description   : Sends the timesettings as json 
*    Input         : non
*    Output        : none
*    Remarks       : none
**************************************************************************************************/ 
uint8_t hex2int2(char ch)
{
    if (ch >= '0' && ch <= '9')
        return ch - '0';
    if (ch >= 'A' && ch <= 'F')
        return ch - 'A' + 10;
    if (ch >= 'a' && ch <= 'f')
        return ch - 'a' + 10;
    return -1;
}

void response_settings(){

char strbuffer[129];
String response="";  

  DynamicJsonDocument root(350);
  memset(strbuffer,0,129);
  datum_t d = timec.GetLocalTimeDate();
  snprintf(strbuffer,64,"%02d:%02d:%02d",d.hour,d.minute,d.second);
  
  root["time"] = strbuffer;
 
  memset(strbuffer,0,129);
  snprintf(strbuffer,64,"%04d-%02d-%02d",d.year,d.month,d.day);
  root["date"] = strbuffer;

  memset(strbuffer,0,129);
  snprintf(strbuffer,129,"%s",NTPC.GetServerName());
  root["ntpname"] = strbuffer;
  root["tzidx"] = (int32_t)timec.GetTimeZone();
  root["ntpena"] = NTPC.GetNTPSyncEna();
  root["ntp_update_span"]=NTPC.GetSyncInterval();
  root["zoneoverride"]=timec.GetTimeZoneManual();;
  root["gmtoffset"]=timec.GetGMT_Offset();;
  root["dlsdis"]=!timec.GetAutomacitDLS();
  root["dlsmanena"]=timec.GetManualDLSEna();
  uint32_t idx = timec.GetDLS_Offset();
  root["dlsmanidx"]=idx;
  serializeJson(root,response);
  sendData(response);
}


/**************************************************************************************************
*    Function      : settime_update
*    Description   : Parses POST for new local time
*    Input         : none
*    Output        : none
*    Remarks       : none
**************************************************************************************************/ 
void settime_update( ){ /* needs to process date and time */
  datum_t d;
  d.year=2000;
  d.month=1;
  d.day=1;
  d.hour=0;
  d.minute=0;
  d.second=0;

  bool time_found=false;
  bool date_found=false;
  
  if( ! server->hasArg("date") || server->arg("date") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missong something here */
  } else {
   
    Serial.printf("found date: %s\n\r",server->arg("date").c_str());
    uint8_t d_len = server->arg("date").length();
    Serial.printf("datelen: %i\n\r",d_len);
    if(server->arg("date").length()!=10){
      Serial.println("date len failed");
    } else {   
      String year=server->arg("date").substring(0,4);
      String month=server->arg("date").substring(5,7);
      String day=server->arg("date").substring(8,10);
      d.year = year.toInt();
      d.month = month.toInt();
      d.day = day.toInt();
      date_found=true;
    }   
  }

  if( ! server->hasArg("time") || server->arg("time") == NULL ) { // If the POST request doesn't have username and password data
    
  } else {
    if(server->arg("time").length()!=8){
      Serial.println("time len failed");
    } else {
    
      String hour=server->arg("time").substring(0,2);
      String minute=server->arg("time").substring(3,5);
      String second=server->arg("time").substring(6,8);
      d.hour = hour.toInt();
      d.minute = minute.toInt();
      d.second = second.toInt();     
      time_found=true;
    }
     
  } 
  if( (time_found==true) && ( date_found==true) ){
    Serial.printf("Date: %i, %i, %i ", d.year , d.month, d.day );
    Serial.printf("Time: %i, %i, %i ", d.hour , d.minute, d.second );
    timec.SetLocalTime(d);
  }
  
  server->send(200);   
 
 }


/**************************************************************************************************
*    Function      : ntp_settings_update
*    Description   : Parses POST for new ntp settings
*    Input         : none
*    Output        : none
*    Remarks       : none
**************************************************************************************************/ 
void ntp_settings_update( ){ /* needs to process NTP_ON, NTPServerName and NTP_UPDTAE_SPAN */

  if( ! server->hasArg("NTP_ON") || server->arg("NTP_ON") == NULL ) { // If the POST request doesn't have username and password data
    NTPC.SetNTPSyncEna(false);  
  } else {
    NTPC.SetNTPSyncEna(true);  
  }

  if( ! server->hasArg("NTPServerName") || server->arg("NTPServerName") == NULL ) { // If the POST request doesn't have username and password data
      
  } else {
     NTPC.SetServerName( server->arg("NTPServerName") );
  }

  if( ! server->hasArg("ntp_update_delta") || server->arg("ntp_update_delta") == NULL ) { // If the POST request doesn't have username and password data
     
  } else {
    NTPC.SetSyncInterval( server->arg("ntp_update_delta").toInt() );
  }
  NTPC.SaveSettings();
  server->send(200);   
  
 }

/**************************************************************************************************
*    Function      : timezone_update
*    Description   : Parses POST for new timezone settings
*    Input         : none
*    Output        : none
*    Remarks       : none
**************************************************************************************************/  
void timezone_update( ){ /*needs to handel timezoneid */
  if( ! server->hasArg("timezoneid") || server->arg("timezoneid") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missong something here */
  } else {
   
    Serial.printf("New TimeZoneID: %s\n\r",server->arg("timezoneid").c_str());
    uint32_t timezoneid = server->arg("timezoneid").toInt();
    timec.SetTimeZone( (TIMEZONES_NAMES_t)timezoneid );   
  }
  timec.SaveConfig();
  server->send(200);    

 }

 
/**************************************************************************************************
*    Function      : timezone_overrides_update
*    Description   : Parses POST for new timzone overrides
*    Input         : none
*    Output        : none
*    Remarks       : none
**************************************************************************************************/  
 void timezone_overrides_update( ){ /* needs to handle DLSOverrid,  ManualDLS, dls_offset, ZONE_OVERRRIDE and GMT_OFFSET */

  bool DLSOverrid=false;
  bool ManualDLS = false;
  bool ZONE_OVERRRIDE = false;
  int32_t gmt_offset = 0;
  DLTS_OFFSET_t dls_offsetidx = DLST_OFFSET_0;
  if( ! server->hasArg("dlsdis") || server->arg("dlsdis") == NULL ) { // If the POST request doesn't have username and password data
      /* we are missing something here */
  } else {
    DLSOverrid=true;  
  }

  if( ! server->hasArg("dlsmanena") || server->arg("dlsmanena") == NULL ) { // If the POST request doesn't have username and password data
      /* we are missing something here */
  } else {
    ManualDLS=true;  
  }

  if( ! server->hasArg("ZONE_OVERRRIDE") || server->arg("ZONE_OVERRRIDE") == NULL ) { // If the POST request doesn't have username and password data
      /* we are missing something here */
  } else {
    ZONE_OVERRRIDE=true;  
  }

  if( ! server->hasArg("gmtoffset") || server->arg("gmtoffset") == NULL ) { // If the POST request doesn't have username and password data
      /* we are missing something here */
  } else {
    gmt_offset = server->arg("gmtoffset").toInt();
  }

  if( ! server->hasArg("dlsmanidx") || server->arg("dlsmanidx") == NULL ) { // If the POST request doesn't have username and password data
      /* we are missing something here */
  } else {
    dls_offsetidx = (DLTS_OFFSET_t) server->arg("dlsmanidx").toInt();
  }
  timec.SetGMT_Offset(gmt_offset);
  timec.SetDLS_Offset( (DLTS_OFFSET_t)(dls_offsetidx) );
  timec.SetAutomaticDLS(!DLSOverrid);
  timec.SetManualDLSEna(ManualDLS);
  timec.SetTimeZoneManual(ZONE_OVERRRIDE);

 
  timec.SaveConfig();
  server->send(200);    

  
 }

/**************************************************************************************************
*    Function      : update_display_sleepmode
*    Description   : Parses POST for new sleeptime 
*    Input         : none
*    Output        : none
*    Remarks       : none
**************************************************************************************************/
void ledactivespan_send( void ){
	
  Serial.println("================> Update Sleep Time ledactivespan_send");

  const size_t capacity = 2*JSON_ARRAY_SIZE(3) + 6*JSON_OBJECT_SIZE(1) + JSON_OBJECT_SIZE(3);
  String response ="";
  lightactivespan_t spandata = LED_GetLEDActiveSpan();
  
  DynamicJsonDocument root(capacity);  
  JsonObject spanstart = root.createNestedObject("spanstart");
  spanstart["hour"] = spandata.start.hour;
  spanstart["minute"] = spandata.start.minute;
  spanstart["second"] = spandata.start.second;
  
  JsonObject spanend = root.createNestedObject("spanend");
  spanend["hour"] = spandata.end.hour;
  spanend["minute"] = spandata.end.minute;
  spanend["second"] = spandata.end.second;
  root["ena"] = spandata.ena;

  serializeJson(root,response);
  sendData(response);
}

void activespan2_send( void ){
	
  Serial.println("================> Update Sleep Time ledactivespan_send");

  const size_t capacity = 2*JSON_ARRAY_SIZE(3) + 6*JSON_OBJECT_SIZE(1) + JSON_OBJECT_SIZE(3);
  String response ="";
  lightactivespan_t spandata = LED_GetLEDActiveSpan2();
  
  DynamicJsonDocument root(capacity);  
  JsonObject spanstart = root.createNestedObject("spanstart");
  spanstart["hour"] = spandata.start.hour;
  spanstart["minute"] = spandata.start.minute;
  spanstart["second"] = spandata.start.second;
  
  JsonObject spanend = root.createNestedObject("spanend");
  spanend["hour"] = spandata.end.hour;
  spanend["minute"] = spandata.end.minute;
  spanend["second"] = spandata.end.second;
  root["ena"] = spandata.ena;

  serializeJson(root,response);
  sendData(response);
}

void activespan3_send( void ){
	
  Serial.println("================> Update Sleep Time ledactivespan_send");

  const size_t capacity = 2*JSON_ARRAY_SIZE(3) + 6*JSON_OBJECT_SIZE(1) + JSON_OBJECT_SIZE(3);
  String response ="";
  lightactivespan_t spandata = LED_GetLEDActiveSpan3();
  
  DynamicJsonDocument root(capacity);  
  JsonObject spanstart = root.createNestedObject("spanstart");
  spanstart["hour"] = spandata.start.hour;
  spanstart["minute"] = spandata.start.minute;
  spanstart["second"] = spandata.start.second;
  
  JsonObject spanend = root.createNestedObject("spanend");
  spanend["hour"] = spandata.end.hour;
  spanend["minute"] = spandata.end.minute;
  spanend["second"] = spandata.end.second;
  root["ena"] = spandata.ena;

  serializeJson(root,response);
  sendData(response);
}

void activespan4_send( void ){
	
  Serial.println("================> Update Sleep Time ledactivespan_send");

  const size_t capacity = 2*JSON_ARRAY_SIZE(3) + 6*JSON_OBJECT_SIZE(1) + JSON_OBJECT_SIZE(3);
  String response ="";
  lightactivespan_t spandata = LED_GetLEDActiveSpan4();
  
  DynamicJsonDocument root(capacity);  
  JsonObject spanstart = root.createNestedObject("spanstart");
  spanstart["hour"] = spandata.start.hour;
  spanstart["minute"] = spandata.start.minute;
  spanstart["second"] = spandata.start.second;
  
  JsonObject spanend = root.createNestedObject("spanend");
  spanend["hour"] = spandata.end.hour;
  spanend["minute"] = spandata.end.minute;
  spanend["second"] = spandata.end.second;
  root["ena"] = spandata.ena;

  serializeJson(root,response);
  sendData(response);
}



/**************************************************************************************************
*    Function      : update_ledactivespan
*    Description   : Parses POST for new sleeptime 
*    Input         : none
*    Output        : none
*    Remarks       : none
**************************************************************************************************/ 
void update_ledactivespan(){
  lightactivespan_t span;
  span.ena=false;
 
  Serial.println("================> Update Sleep Time update_ledactivespan");
  
  if( ! server->hasArg("enable") || server->arg("enable") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
    if(server->arg("enable") == "true"){
      span.ena = true;
    } else {
      span.ena = false;
    }
    
  }
  /* we also need the times for the mode */
  if( ! server->hasArg("silent_start") || server->arg("silent_start") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
    if(server->arg("silent_start").length()!=8){
      Serial.println("silent_start len failed");
    } else {
    
      String hour=server->arg("silent_start").substring(0,2);
      String minute=server->arg("silent_start").substring(3,5);
      String second=server->arg("silent_start").substring(6,8);
      span.start.hour = hour.toInt();
      span.start.minute = minute.toInt();
      span.start.second = second.toInt();
     
  
    }
    
  }

  if( ! server->hasArg("silent_end") || server->arg("silent_end") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
     if(server->arg("silent_end").length()!=8){
      Serial.println("silent_end len failed");
    } else {
    
      String hour=server->arg("silent_end").substring(0,2);
      String minute=server->arg("silent_end").substring(3,5);
      String second=server->arg("silent_start").substring(6,8);
      span.end.hour = hour.toInt();
      span.end.minute = minute.toInt();
      span.end.second = second.toInt();
     
    }
  }

/* we need to setup something for the led to use this values */
  LED_SetLEDActiveSpan(span);
  server->send(200);    
}

void update_activespan2(){
  lightactivespan_t span;
  span.ena=false;
 
  Serial.println("================> Update Sleep Time update_ledactivespan");
  
  if( ! server->hasArg("enable2") || server->arg("enable2") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
    if(server->arg("enable2") == "true"){
      span.ena = true;
    } else {
      span.ena = false;
    }
    
  }
  /* we also need the times for the mode */
  if( ! server->hasArg("silent_start2") || server->arg("silent_start2") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
    if(server->arg("silent_start2").length()!=8){
      Serial.println("silent_start len failed");
    } else {
    
      String hour=server->arg("silent_start2").substring(0,2);
      String minute=server->arg("silent_start2").substring(3,5);
      String second=server->arg("silent_start2").substring(6,8);
      span.start.hour = hour.toInt();
      span.start.minute = minute.toInt();
      span.start.second = second.toInt();
    }
    
  }

  if( ! server->hasArg("silent_end2") || server->arg("silent_end2") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
     if(server->arg("silent_end2").length()!=8){
      Serial.println("silent_end len failed");
    } else {
    
      String hour=server->arg("silent_end2").substring(0,2);
      String minute=server->arg("silent_end2").substring(3,5);
      String second=server->arg("silent_start2").substring(6,8);
      span.end.hour = hour.toInt();
      span.end.minute = minute.toInt();
      span.end.second = second.toInt();
     
    }
  }

/* we need to setup something for the led to use this values */
  LED_SetLEDActiveSpan2(span);
  server->send(200);    
}



/**************************************************************************************************
*    Function      : update_notes
*    Description   : Parses POST for new notes
*    Input         : none
*    Output        : none
*    Remarks       : none
**************************************************************************************************/ 
void update_notes(){
  char data[501]={0,};
  if( ! server->hasArg("notes") || server->arg("notes") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("New Notes: %s\n\r",server->arg("notes").c_str());
    /* direct commit */
    uint32_t str_size = server->arg("notes").length();
    if(str_size<501){
      strncpy((char*)data,server->arg("notes").c_str(),501);
      eepwrite_notes((uint8_t*)data,501);
    } else {
      Serial.println("Note > 512 char");
    }
  }

  server->send(200);    
}

void update_MAC1(){
  char data[21]={0,};
  if( ! server->hasArg("MAC1") || server->arg("MAC1") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("New MAC1: %s\n\r",server->arg("MAC1").c_str());
    /* direct commit */
    uint32_t str_size = server->arg("MAC1").length();
    if(str_size<21){
      strncpy((char*)data,server->arg("MAC1").c_str(),21);
      eepwrite_MAC1((uint8_t*)data,21);
    } else {
      Serial.println("MAC1 > 21 char");
    }
  }

  server->send(200);    
}

void update_MAC2(){
  char data[21]={0,};
  if( ! server->hasArg("MAC2") || server->arg("MAC2") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("New MAC2: %s\n\r",server->arg("MAC2").c_str());
    /* direct commit */
    uint32_t str_size = server->arg("MAC2").length();
    if(str_size<21){
      strncpy((char*)data,server->arg("MAC2").c_str(),21);
      eepwrite_MAC2((uint8_t*)data,21);
    } else {
      Serial.println("MAC2 > 21 char");
    }
  }

  server->send(200);    
}

void update_MAC3(){
  char data[21]={0,};
  if( ! server->hasArg("MAC3") || server->arg("MAC3") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("New MAC3: %s\n\r",server->arg("MAC3").c_str());
    /* direct commit */
    uint32_t str_size = server->arg("MAC3").length();
    if(str_size<21){
      strncpy((char*)data,server->arg("MAC3").c_str(),21);
      eepwrite_MAC3((uint8_t*)data,21);
    } else {
      Serial.println("MAC3 > 21 char");
    }
  }

  server->send(200);    
}

void update_MAC4(){
  char data[21]={0,};
  if( ! server->hasArg("MAC4") || server->arg("MAC4") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("New MAC4: %s\n\r",server->arg("MAC4").c_str());
    /* direct commit */
    uint32_t str_size = server->arg("MAC4").length();
    if(str_size<21){
      strncpy((char*)data,server->arg("MAC4").c_str(),21);
      eepwrite_MAC4((uint8_t*)data,21);
    } else {
      Serial.println("MAC4 > 21 char");
    }
  }

  server->send(200);    
}

void update_MAC5(){
  char data[21]={0,};
  if( ! server->hasArg("MAC5") || server->arg("MAC5") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("New MAC5: %s\n\r",server->arg("MAC5").c_str());
    /* direct commit */
    uint32_t str_size = server->arg("MAC5").length();
    if(str_size<21){
      strncpy((char*)data,server->arg("MAC5").c_str(),21);
      eepwrite_MAC5((uint8_t*)data,21);
    } else {
      Serial.println("MAC5 > 21 char");
    }
  }

  server->send(200);    
}

void update_MAC6(){
  char data[21]={0,};
  if( ! server->hasArg("MAC6") || server->arg("MAC6") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("New MAC6: %s\n\r",server->arg("MAC6").c_str());
    /* direct commit */
    uint32_t str_size = server->arg("MAC6").length();
    if(str_size<21){
      strncpy((char*)data,server->arg("MAC6").c_str(),21);
      eepwrite_MAC6((uint8_t*)data,21);
    } else {
      Serial.println("MAC6 > 21 char");
    }
  }

  server->send(200);    
}

void update_timer(){
  char data[21]={0,};
  if( ! server->hasArg("TIMER") || server->arg("TIMER") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("New TIMER: %s\n\r",server->arg("TIMER").c_str());
    /* direct commit */
    uint32_t str_size = server->arg("TIMER").length();
	
	Serial.print("LENGTH: ");
	Serial.print(str_size);
	
    if(str_size<21){
      strncpy((char*)data,server->arg("TIMER").c_str(),21);
      eepwrite_timer((uint8_t*)data,21);
	  //timeToRun = hex2int2(int(data[0]));
	  //Serial.println("TIME2RUN ");
	  //Serial.println(String(timeToRun));
    } else {
      Serial.println("TIMER > 21 char");
    }
  }

  server->send(200);    
}

void update_ledeffect(){
  char data[21]={0,};
  if( ! server->hasArg("LED_EFFECT") || server->arg("LED_EFFECT") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("New Led effect: %s\n\r",server->arg("LED_EFFECT").c_str());
    /* direct commit */
    uint32_t str_size = server->arg("LED_EFFECT").length();
	
	Serial.print("LENGTH: ");
	Serial.print(str_size);
	
    if(str_size<21){
      strncpy((char*)data,server->arg("LED_EFFECT").c_str(),21);
      eepwrite_ledeffect((uint8_t*)data,21);
    } else {
      Serial.println("LED EFFECT > 21 char");
    }
  }

  server->send(200);    
}


void updateSystemState(){
  char data[21]={0,};
  char data_effect[21]={0,};
  
  
  
  if( ! server->hasArg("SYSTEM_STATE") || server->arg("SYSTEM_STATE") == NULL ) { // If the POST request doesn't have username and password data
    /* we are missing something here */
  } else {
   
    Serial.printf("COMMAND TO CHANGE SYSTEM STATE: %s\n\r",server->arg("SYSTEM_STATE").c_str());
	
	
	eepread_systemState((uint8_t*)data,21);
    Serial.print("SYSTEM STATE DATA BEFORE: ");
    Serial.println(String(data));
	
	
	/*
	char *outputInfor = NULL;
	int dataChange = 0;
	
	
	outputInfor = strstr (data,"RUNN");
    if(outputInfor) {
        Serial.println("SYSTEM STATE is RUNNING");
		//strncpy((char*)data,"IDLE",21);
		dataChange = 1;
    }
	
	outputInfor = strstr (data,"IDLE");
	if(outputInfor) {
        Serial.println("SYSTEM STATE is IDLE");
		//strncpy((char*)data,"RUNNING",21);
		dataChange = 2;
    }
	
	strncpy((char*)data_effect,"C",21);
	strncpy((char*)data,"ERROR",21);
	
	if(dataChange == 1){
		strncpy((char*)data,"IDLE",21);
		strncpy((char*)data_effect,"A",21);
    }
	
	if(dataChange == 2){
		strncpy((char*)data,"RUNN",21);
		strncpy((char*)data_effect,"B",21);
    }
	*/
	
    /* direct commit */
    uint32_t str_size = server->arg("SYSTEM_STATE").length();
	
	Serial.print("LENGTH: ");
	Serial.println(str_size);
	
	switch(systemState){
	    case SYSTEM_RUNNING: 
	        systemState = SYSTEM_IDLE;
		    strncpy((char*)data,"IDLE",21); 
			systemChangeCode = SYSTEM_RUNN_IDLE;
		    break;
			
		case SYSTEM_IDLE: 
	        systemState = SYSTEM_RUNNING;
		    strncpy((char*)data,"RUNN",21);
			systemChangeCode = SYSTEM_IDLE_RUNN;
		    break;
			
		default:
		    break;
	
	}
	
	/*
	if(var == 100){
	     Serial.print("VAR is change be MAIN");
	     Serial.println(String(var));
    }
	else{
		 var = 10;
	     Serial.print("VAR is NOT CHANGED");
	     Serial.println(String(var));	
	}
	
	*/
    
	if(str_size<21){
	  //strncpy((char*)data,"HIEU",21);
      //eepwrite_systemState((uint8_t*)data,21);
	  Serial.println("Should we write data to ROM???");
    } else {
      Serial.println("SYSTEM_STATE > 21 char");
    }
	
  }

  server->send(200);    
  //sendData(data);
}


/**************************************************************************************************
*    Function      : read_notes
*    Description   : none
*    Input         : none
*    Output        : none
*    Remarks       : Retunrs the notes as plain text
**************************************************************************************************/ 
void read_notes(){
  char data[501]={0,};
  eepread_notes((uint8_t*)data,501);
  sendData(data);    
}


void read_MAC1(){
  char data[21]={0,};
  eepread_MAC1((uint8_t*)data,21);
  Serial.print("Read MAC1: ");
  Serial.println(String(data[0]));
  sendData(data);    
}

void read_MAC2(){
  char data[21]={0,};
  eepread_MAC2((uint8_t*)data,21);
  sendData(data);    
}

void read_MAC3(){
  char data[21]={0,};
  eepread_MAC3((uint8_t*)data,21);
  sendData(data);    
}

void read_MAC4(){
  char data[21]={0,};
  eepread_MAC4((uint8_t*)data,21);
  sendData(data);    
}

void read_MAC5(){
  char data[21]={0,};
  eepread_MAC5((uint8_t*)data,21);
  sendData(data);    
}

void read_MAC6(){
  char data[21]={0,};
  eepread_MAC6((uint8_t*)data,21);
  sendData(data);    
}

void read_timer(){
  char data[21]={0,};
  eepread_timer((uint8_t*)data,21);
  sendData(data);    
}

void read_ledeffect(){
  char data[21]={0,};
  eepread_ledeffect((uint8_t*)data,21);
  sendData(data);    
}


void getSystemState(){
  char data[21]={0,};
  //data = "FROM ESP"
  
  /*
  char dataMac1[21]={0,};
  eepread_MAC1((uint8_t*)dataMac1,21);
  Serial.print("MAC DATA IN ROM: ");
  Serial.println(String(dataMac1));
  */
  
  //eepread_systemState((uint8_t*)data,21);
  //Serial.print("MAC DATA IN ROM: ");
  //Serial.println(String(data));
  
  
  switch(systemState){
	    case SYSTEM_RUNNING: 
		    strncpy((char*)data,"RUNN",21); 
		    break;
			
		case SYSTEM_IDLE: 
		    strncpy((char*)data,"IDLE",21);
		    break;
			
		default:
		    strncpy((char*)data,"NANA",21);
		    break;
	
  }
	
  /*
  for(int i=0;i<21; i++){
	Serial.print("SYSTEM STATE");    
	Serial.println(data[i]);  
  }
  String test = "TEST";
  */
  sendData(data);    
  //sendData(test);    
}
/**************************************************************************************************
*    Function      : led_update
*    Description   : Parses POST for new led settings
*    Input         : none
*    Output        : none
*    Remarks       : none
**************************************************************************************************/  
void led_update( ){ /* sets the new PWM Value */
  uint32_t value = 0;
  
  neo_settings = eepread_neoSettings();
  
  if( ! server->hasArg("channel0") || server->arg("channel0") == NULL ) { 
    /* we are missong something here */
  } else {
   
    value = server->arg("channel0").toInt();
    if(value > UINT16_MAX ){
      value = UINT16_MAX;
    }
    Serial.print("UPDATE BRIGHNESS: ");
	Serial.print(String(value));
	neo_settings.intensity = value;
  }
  
  if( ! server->hasArg("channel1") || server->arg("channel1") == NULL ) { 
    /* we are missong something here */
  } else {
    Serial.print("UPDATE SLOW SPEED: ");
	neo_settings.ledSpeed = 1;
  }
  
  if( ! server->hasArg("channel2") || server->arg("channel2") == NULL ) { 
    /* we are missong something here */
  } else {
    Serial.print("UPDATE NORMAL SPEED: ");
	neo_settings.ledSpeed = 2;
  }
  
  if( ! server->hasArg("channel3") || server->arg("channel3") == NULL ) { 
    /* we are missong something here */
  } else {
    Serial.print("UPDATE FAST SPEED: ");
	neo_settings.ledSpeed = 3;
  }
  
  if( ! server->hasArg("channel4") || server->arg("channel4") == NULL ) { 
    /* we are missong something here */
  } else {
   
    value = server->arg("channel4").toInt();
    if(value > UINT16_MAX ){
      value = UINT16_MAX;
    }
    Serial.print("UPDATE NO OF LED: ");
	Serial.print(String(value));
	neo_settings.noOfLed = value;
  }

  //neo_settings.intensity = value;
  neo_settings.led_r = 11;
  neo_settings.led_g = 11;
  neo_settings.led_b = 11;
    
  eepwrite_neoSettings(neo_settings);	
	
  ws_sendledvalues();
  server->send(200);    

 }

/**************************************************************************************************
*    Function      : led_status
*    Description   : Process GET for led settings
*    Input         : none
*    Output        : none
*    Remarks       : none
**************************************************************************************************/  
void led_status( ){ 

  const size_t capacity = JSON_ARRAY_SIZE(4) + JSON_OBJECT_SIZE(3);
  String response ="";
  DynamicJsonDocument root(capacity);

  root["intensity"] = LED_GetIntensity();
  
  JsonArray led_value = root.createNestedArray("led_value");
  for(uint32_t i=0;i<LED_CNT;i++){
    uint16_t value = LED_GetValue((LEDCH_t)i);
    led_value.add(value);  
  }
  serializeJson(root,response);
  sendData(response);
}


void mqttsettings_update( ){
 
  mqttsettings_t Data = eepread_mqttsettings();
  
  if( ! server->hasArg("MQTT_USER") || server->arg("MQTT_USER") == NULL ) { 
    /* we are missong something here */
  } else { 
    String value = server->arg("MQTT_USER");
    strncpy(Data.mqttusername, value.c_str(),128);
  }

  if( ! server->hasArg("MQTT_PASS") || server->arg("MQTT_PASS") == NULL ) { 
    /* we are missong something here */
  } else { 
    String value = server->arg("MQTT_PASS");
    strncpy(Data.mqttpassword, value.c_str(),128);
  }

  if( ! server->hasArg("MQTT_SERVER") || server->arg("MQTT_SERVER") == NULL ) { 
    /* we are missong something here */
  } else { 
    String value = server->arg("MQTT_SERVER");
    strncpy(Data.mqttservename, value.c_str(),128);
  }

  if( ! server->hasArg("MQTT_HOST") || server->arg("MQTT_HOST") == NULL ) { 
    /* we are missong something here */
  } else { 
    String value = server->arg("MQTT_HOST");
    strncpy(Data.mqtthostname, value.c_str(),64);
  }

  if( ! server->hasArg("MQTT_PORT") || server->arg("MQTT_PORT") == NULL ) { 
    /* we are missong something here */
  } else { 
    int32_t value = server->arg("MQTT_PORT").toInt();
    if( (value>=0) && ( value<=UINT16_MAX ) ){
      Data.mqttserverport = value;
    }
  }
  
  if( ! server->hasArg("MQTT_TOPIC") || server->arg("MQTT_TOPIC") == NULL ) { 
    /* we are missong something here */
  } else { 
    String value = server->arg("MQTT_TOPIC");
    strncpy(Data.mqtttopic, value.c_str(),500);
  }

  if( ! server->hasArg("MQTT_ENA") || server->arg("MQTT_ENA") == NULL ) { 
    /* we are missing something here */
  } else { 
    bool value = false;
    if(server->arg("MQTT_ENA")=="true"){
      value = true;
    }
    Data.enable = value;
  }
  
  /* write data to the eeprom */
  eepwrite_mqttsettings(Data);
  
  xTaskNotify( MQTTTaskHandle, 0x01, eSetBits );
  server->send(200); 

}


/*
  char mqttservename[129];
  uint16_t mqttserverport;
  char mqttusername[129];
  char mqttpassword[129];
  char mqtttopic[501];
  char mqtthostname[65];
 */
void read_mqttsetting(){
   String response ="";
  mqttsettings_t Data = eepread_mqttsettings();
  DynamicJsonDocument root(2000);
  

  root["mqttena"]= (bool)(Data.enable);
  root["mqttserver"] = String(Data.mqttservename);
  root["mqtthost"] = String(Data.mqtthostname);
  root["mqttport"] = Data.mqttserverport;
  root["mqttuser"] = String(Data.mqttusername);
  root["mqtttopic"] = String(Data.mqtttopic);
  if(Data.mqttpassword[0]!=0){
    root["mqttpass"] = "********";
  } else {
    root["mqttpass"] ="";
  }

  serializeJson(root,response);
  sendData(response);

}
